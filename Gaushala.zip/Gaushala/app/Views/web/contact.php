<style>
    .map-container {
      position: relative;
      padding-bottom: 56.25%;
      height: 0;
      overflow: hidden;
    }
    .map-container iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
    .social-icons a {
      font-size: 1.5rem;
      margin-right: 15px;
      color: #555;
      transition: color 0.3s;
    }
    .social-icons a:hover {
      color: #007bff;
    }
  </style>

<!-- Contact Section -->
<section class="container my-5">
  <h2 class="text-center mb-5">Contact Us</h2>

  <!-- Contact Form and Details -->
  <div class="row">
    <div class="col-md-6 mb-4 d-flex flex-column">
      <h4>Send Us a Message</h4>
      <form id="contactForm">
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" class="form-control" id="name" placeholder="Your Name" required>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" placeholder="Your Email" required>
        </div>
        <div class="form-group">
          <label for="subject">Subject</label>
          <select class="form-control" id="subject" required>
            <option value="">Select a Subject</option>
            <option value="general">General Inquiry</option>
            <option value="donations">Donations</option>
            <option value="volunteering">Volunteering</option>
            <option value="events">Event Registration</option>
          </select>
        </div>
        <div class="form-group">
          <label for="message">Message</label>
          <textarea class="form-control" id="message" rows="5" placeholder="Your Message" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
      <div id="formMessage" class="mt-3"></div>
    </div>

    <!-- Contact Details -->
    <div class="col-md-6 mb-4 d-flex flex-column">
      <h4>Find Us</h4>
      <p><strong>Address:</strong> Shree Ujjwal Gorakshak Sanstha, XYZ Road, City, Postal Code</p>
      <p><strong>Phone:</strong> <a href="tel:+1234567890">+1 234-567-890</a> (9 AM - 6 PM)</p>
      <p><strong>Email:</strong> <a href="mailto:info@goushala.com">info@goushala.com</a></p>
      <p><strong>Social Media:</strong></p>
      <div class="social-icons">
        <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
        <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
  </div>

  <!-- Google Map -->
  <div class="map-container mt-4">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14980.10093754522!2d73.9621091!3d20.1746748!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdddb0022884d57%3A0x8dafb8619a6ff2c0!2sGaushala%20Shri%20Ujjwal%20Gorakshan%20Sanstha%20Pimpalgaon%20%7BB%7D!5e0!3m2!1sen!2sin!4v1731173412423!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>
</section>
<!-- Confirmation and JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script>
  $('#contactForm').on('submit', function(event) {
    event.preventDefault();
    $('#formMessage').html('<p class="text-success">Thank you for reaching out! We’ll get back to you shortly.</p>');
    setTimeout(function() {
      $('#contactForm')[0].reset();
      $('#formMessage').empty();
    }, 3000);
  });
</script>

