<style>
    .thumbnail img {
        height: 200px;
        width: 100%;
        object-fit: cover;
        transition: transform 0.2s;
    }

    .thumbnail:hover img {
        transform: scale(1.05);
    }
</style>
<!-- Image and Video Gallery Section -->
<section class="container my-5">
    <h2 class="text-center mb-5">Image and Video Gallery</h2>

    <!-- Events Category -->
    <div class="gallery-category mb-5">
        <h3>Events</h3>
        <div class="row d-flex flex-wrap">
            <!-- Image 1 -->
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Festival Celebration 1" data-src="event1.jpg"
                    data-description="Photos from our recent festival celebration.">
                    <img src="<?= base_url(); ?>public/web/img/a_cow_is_sitting_in_gaushala.jpeg" alt="Festival Celebration 1" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Festival Celebration 1</p>
                    </div>
                </div>
            </div>

            <!-- Image 2 -->
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Festival Celebration 2" data-src="event2.jpg"
                    data-description="More photos from the festival celebration.">
                    <img src="<?= base_url(); ?>public/web/img/cow_with_there_baby_sitting_in_goushala.jpeg" alt="Festival Celebration 2"
                        class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Festival Celebration 2</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Festival Celebration 2" data-src="event2.jpg"
                    data-description="More photos from the festival celebration.">
                    <img src="<?= base_url(); ?>public/web/img/cow_with_there_baby_sitting_in_goushala.jpeg" alt="Festival Celebration 2"
                        class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Festival Celebration 2</p>
                    </div>
                </div>
            </div>


            <!-- Additional images as needed, following the same structure -->
        </div>
    </div>

    <!-- Daily Activities Category -->
    <div class="gallery-category mb-5">
        <h3>Daily Activities</h3>
        <div class="row d-flex flex-wrap">
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Cow Feeding 1" data-src="activity1.jpg"
                    data-description="Daily feeding session with our cows.">
                    <img src="<?= base_url(); ?>public/web/img/img1.jpg" alt="Cow Feeding 1" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Cow Feeding 1</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Cow Feeding 2" data-src="activity2.jpg" data-description="Another view of cow feeding.">
                    <img src="<?= base_url(); ?>public/web/img/img2.jpg" alt="Cow Feeding 2" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Cow Feeding 2</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Cow Feeding 1" data-src="activity1.jpg"
                    data-description="Daily feeding session with our cows.">
                    <img src="<?= base_url(); ?>public/web/img/img1.jpg" alt="Cow Feeding 1" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Cow Feeding 1</p>
                    </div>
                </div>
            </div>

            <!-- Additional daily activity images as needed -->
        </div>
    </div>

    <!-- Sponsorships and Adoptions Category -->
    <div class="gallery-category mb-5">
        <h3>Sponsorships and Adoptions</h3>
        <div class="row d-flex flex-wrap">
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Adopted Cow 1" data-src="adoption1.jpg"
                    data-description="This cow is sponsored by one of our supporters.">
                    <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala.jpeg" alt="Adopted Cow 1" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Adopted Cow 1</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Adopted Cow 2" data-src="adoption2.jpg" data-description="Another sponsored cow.">
                    <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala_in_landscape.jpeg" alt="Adopted Cow 2" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Adopted Cow 2</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="image"
                    data-title="Adopted Cow 2" data-src="adoption2.jpg" data-description="Another sponsored cow.">
                    <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala_in_landscape.jpeg" alt="Adopted Cow 2" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">Adopted Cow 2</p>
                    </div>
                </div>
            </div>

            <!-- Additional sponsorship and adoption images as needed -->
        </div>
    </div>

    <!-- Special Programs and Visits Category -->
    <div class="gallery-category mb-5">
        <h3>Special Programs and Visits</h3>
        <div class="row d-flex flex-wrap">
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="video"
                    data-title="School Visit" data-src="program1.mp4"
                    data-description="Students from nearby schools visiting our Gau Shala.">
                    <img src="<?= base_url(); ?>public/web/img/Untitled design (1).png" alt="School Visit" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">School Visit</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="video"
                    data-title="School Visit" data-src="program1.mp4"
                    data-description="Students from nearby schools visiting our Gau Shala.">
                    <img src="<?= base_url(); ?>public/web/img/Untitled design (1).png" alt="School Visit" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">School Visit</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4 d-flex">
                <div class="card thumbnail" data-toggle="modal" data-target="#mediaModal" data-media="video"
                    data-title="School Visit" data-src="program1.mp4"
                    data-description="Students from nearby schools visiting our Gau Shala.">
                    <img src="<?= base_url(); ?>public/web/img/Untitled design (1).png" alt="School Visit" class="img-fluid">
                    <div class="card-body text-center">
                        <p class="card-text">School Visit</p>
                    </div>
                </div>
            </div>

            <!-- Additional special program images or videos as needed -->
        </div>
    </div>
</section>

<!-- Modal for Viewing Media -->
<div class="modal fade" id="mediaModal" tabindex="-1" role="dialog" aria-labelledby="mediaModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediaTitle"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p id="mediaDescription"></p>
                <div id="mediaContent"></div>
            </div>
        </div>
    </div>
</div>

<!-- Social Media Section -->
<section class="container social-media-section my-5">
    <h2 class="text-center mb-5">Follow Us on Social Media</h2>
    <div class="row d-flex flex-wrap">
        <div class="col-md-3 mb-4 d-flex">
            <div class="card">
                <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Social Media Post">
                <div class="card-body">
                    <p class="card-text">Our latest event updates! #GauShala #AdoptACow</p>
                    <a href="#" class="btn btn-primary btn-sm" target="_blank">View on Instagram</a>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4 d-flex">
            <div class="card">
                <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Social Media Post">
                <div class="card-body">
                    <p class="card-text">Our latest event updates! #GauShala #AdoptACow</p>
                    <a href="#" class="btn btn-primary btn-sm" target="_blank">View on Instagram</a>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4 d-flex">
            <div class="card">
                <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card   -img-top" alt="Social Media Post">
                <div class="card-body">
                    <p class="card-text">Our latest event updates! #GauShala #AdoptACow</p>
                    <a href="#" class="btn btn-primary btn-sm" target="_blank">View on Instagram</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4 d-flex">
            <div class="card">
                <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Social Media Post">
                <div class="card-body">
                    <p class="card-text">Our latest event updates! #GauShala #AdoptACow</p>
                    <a href="#" class="btn btn-primary btn-sm" target="_blank">View on Instagram</a>
                </div>
            </div>
        </div>
        <!-- Additional social media posts as needed -->
    </div>
</section>