<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gau Shala</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="<?= base_url(); ?>public/web/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <!-- Header Section -->
  <header class="bg-light py-3">
    <div class="container d-flex align-items-center justify-content-between">
      <a href="<?= base_url(); ?>" class="navbar-brand">
        <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" alt="Gau Shala Logo" style="height: 70px;" style="mix-blend-mode:multiply;">
      </a>
      <nav>
        <ul class="nav">
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>services">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>donations">Donations</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>events">Events</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>gallery">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>contact">Contact</a></li>
        </ul>
      </nav>
      <div>
    </div>
</header>
