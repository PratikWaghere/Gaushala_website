<!-- List of Services Section -->
<section class="p-5 bg-white">
    <div class="container text-center justify-content-center">
      <div class="row">
        <h2 class="text-center mb-4">Services</h2>
      </div>
    </div>
  
    <div class="container">
      <div class="row text-center">
        <!-- Funeral Program Service -->
        <div class="col-md-12 mb-4">
          <div class="card shadow-sm ser-page d-flex flex-row">
            <!-- Image Section -->
            <div class="img-ser col-md-3 d-flex justify-content-center align-items-center" style="flex: 1;">
              <img src="<?= base_url(); ?>public/web/img/a_cow_is_sitting_in_gaushala.jpeg" class="card-img-top" alt="Funeral Service" style="max-width: 100%; height: auto;">
            </div>
            <!-- Text Section -->
            <div class="card-body col-md-9 d-flex flex-column justify-content-center" style="flex: 2;">
              <h5 class="card-title">Funeral Program Services</h5>
              <p class="card-text">We provide a serene environment for individuals to perform final rites, adhering to cultural traditions. Our facilities offer families peace and a spiritual atmosphere for these important ceremonies.</p>
            </div>
          </div>
        </div>
  
        <!-- Cattle Feed Management -->
        <div class="col-md-12 mb-4">
          <div class="card shadow-sm d-flex flex-row">
            <!-- Text Section -->
            <div class="card-body col-md-9 d-flex flex-column justify-content-center" style="flex: 2;">
              <h5 class="card-title">Cattle Feed Management</h5>
              <p class="card-text">We ensure all cows receive nutritious meals with a regular feeding schedule. Special care is given to calves, pregnant cows, and elderly cows. Visitors can participate in the feed management as part of Gau Seva.</p>
            </div>
             <!-- Image Section -->
             <div class="img-ser col-md-3 d-flex justify-content-center align-items-center" style="flex: 1;">
                <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala.jpeg" class="card-img-top" alt="Cattle Feed Management" style="max-width: 100%; height: auto;">
              </div>
          </div>
        </div>
  
        <!-- Educational Programs -->
        <div class="col-md-12 mb-4">
          <div class="card shadow-sm d-flex flex-row">
            <!-- Image Section -->
            <div class="img-ser col-md-3 d-flex justify-content-center align-items-center" style="flex: 1;">
              <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala.jpeg" class="card-img-top" alt="Educational Programs" style="max-width: 100%; height: auto;">
            </div>
            <!-- Text Section -->
            <div class="card-body col-md-9 d-flex flex-column justify-content-center" style="flex: 2;">
              <h5 class="card-title">Educational Programs</h5>
              <p class="card-text">We offer workshops, seminars, and online sessions about cow welfare, sustainable farming, and the ecological importance of cows. These programs help raise awareness and engage the community.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
<!-- Adopt-a-Cow Program Section -->
<section class="p-5 bg-light">
    <div class="container">
        <div class="text-center mb-4">
            <h2>Adopt-a-Cow Program</h2>
            <p class="lead">Sponsor a cow and make a meaningful contribution to its welfare. Your sponsorship ensures the best care for our cows and fosters a sacred bond between you and Gau Mata.</p>
          </div>
    </div>


    <div class="container">
      <!-- Gallery Section -->
      <div class="row text-center">
        <!-- Sponsorship Explanation -->
        <div class="col-md-6 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">How It Works</h5>
              <p class="card-text">By sponsoring a cow, you ensure it receives nutritious food, shelter, and regular veterinary care. Your sponsorship helps us provide ongoing support for the cows, and you can follow the progress of your adopted cow with regular updates.</p>
            </div>
          </div>
        </div>
        <!-- Benefits for Sponsors -->
        <div class="col-md-6 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Benefits for Sponsors</h5>
              <ul class="list-unstyled">
                <li>Personalized donation certificate</li>
                <li>Regular updates on your sponsored cow</li>
                <li>Exclusive access to annual sponsor events</li>
                <li>Visit your adopted cow at the Gau Shala</li>
              </ul>
              <a href="#sponsor" class="btn btn-primary mt-auto">Adopt a Cow</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  

<!-- School Visits and Field Trips Section -->
<section class="p-5 bg-white">
    <div class="container">
        <div class="row">
            <div class="text-center mb-4">
                <h2>School Visits & Field Trips</h2>
                <p class="lead">Our interactive school visits and field trips offer students the opportunity to learn about cows, animal care, and cultural values. The experience fosters compassion and awareness among young visitors.</p>
              </div>
        </div>
    </div>


    <div class="container">
      <!-- Title and Description -->
      <!-- Gallery Section -->
      <div class="row text-center">
        <!-- Overview of Visits -->
        <div class="col-md-6 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Overview</h5>
              <p class="card-text">School visits offer an immersive experience where students can engage in activities like observing feeding routines, learning about cow care, and understanding the cultural significance of cows in Indian tradition.</p>
            </div>
          </div>
        </div>
        <!-- Educational Experience -->
        <div class="col-md-6 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Educational Experience</h5>
              <p class="card-text">Students can participate in hands-on activities, such as feeding cows or assisting in simple chores. We also provide educational resources like pamphlets, presentations, and Q&A sessions with our caretakers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="text-center mt-4">
        <a href="#book-visit" class="btn btn-primary">Book a Visit</a>
      </div>
  </section>
  