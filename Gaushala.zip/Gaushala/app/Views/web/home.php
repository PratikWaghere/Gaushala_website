<section class="carousel-section py-5">
    <div class="container d-flex justify-content-center">
      <div id="smallCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="3000" style="width: 100%; max-width: 2000px;">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala.jpeg" class="d-block w-100 rounded" alt="Cow image 1">
            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
              <h5 class="text-light">Preserving Gau Shala</h5>
              <p class="text-light small">Join us in honoring Gau Mata</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala_in_landscape.jpeg" class="d-block w-100 rounded" alt="Cow image 2">
            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
              <h5 class="text-light">Support Our Mission</h5>
              <p class="text-light small">Help provide shelter and care</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="<?= base_url(); ?>public/web/img/Untitled design (1).png" class="d-block w-100 rounded" alt="Cow image 3">
            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
              <h5 class="text-light">Get Involved Today</h5>
              <p class="text-light small">Adopt a cow and support our cause</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#smallCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#smallCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </section>
  

  <!-- Mission Section with Video Carousel -->
  <section class="mission py-5 bg-light">
    <div class="text-center">
        <h2 class="text-center mb-4 text-dark">Our Mission</h2>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div id="missionCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <!-- <video src="./img/lv_0_20241027193511.mp4" controls class="d-block w-100"></video> -->
                <iframe width="560" height="315" src="https://www.youtube.com/embed/rgTT2tenb50?si=nYyKEBdTfeihLblz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
              </div>
              <div class="carousel-item">
                <!-- <video src="./img/WhatsApp Video 2024-10-27 at 21.50.27.mp4" controls class="d-block w-100"></video> -->
                <iframe width="560" height="315" src="https://www.youtube.com/embed/rgTT2tenb50?si=nYyKEBdTfeihLblz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
              </div>
              <!-- Add more carousel items as needed -->
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#missionCarousel" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#missionCarousel" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
        <div class="col-md-6 d-flex align-items-center">
          <p>Our mission is to protect and honor Gau Mata, offering shelter, love, and care. Our unique designs for the shelter and natural feeding zones provide a safe haven for these sacred animals.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Events Section with Bootstrap Cards -->
  <section class="events py-5">
    <div class="text-center">
        <h2 class="text-center mb-4">Events</h2>
    </div>
    <div class="container">
      
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card h-100">
            <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 1">
            <div class="card-body">
              <h5 class="card-title">Festival Celebration</h5>
              <p class="card-text">Join us for a special celebration of traditional values.</p>
              <a href="#event1" class="btn btn-outline-primary">View Details</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card h-100">
            <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 2">
            <div class="card-body">
              <h5 class="card-title">Volunteer Day</h5>
              <p class="card-text">Spend a day helping us take care of Gau Mata.</p>
              <a href="#event2" class="btn btn-outline-primary">View Details</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100">
              <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 2">
              <div class="card-body">
                <h5 class="card-title">Volunteer Day</h5>
                <p class="card-text">Spend a day helping us take care of Gau Mata.</p>
                <a href="#event2" class="btn btn-outline-primary">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card h-100">
              <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 2">
              <div class="card-body">
                <h5 class="card-title">Volunteer Day</h5>
                <p class="card-text">Spend a day helping us take care of Gau Mata.</p>
                <a href="#event2" class="btn btn-outline-primary">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card h-100">
              <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 2">
              <div class="card-body">
                <h5 class="card-title">Volunteer Day</h5>
                <p class="card-text">Spend a day helping us take care of Gau Mata.</p>
                <a href="#event2" class="btn btn-outline-primary">View Details</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card h-100">
              <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Event 2">
              <div class="card-body">
                <h5 class="card-title">Volunteer Day</h5>
                <p class="card-text">Spend a day helping us take care of Gau Mata.</p>
                <a href="#event2" class="btn btn-outline-primary">View Details</a>
              </div>
            </div>
          </div>
        <!-- Add more event cards as needed -->
      </div>
    </div>
  </section>

  <!-- Gallery Section with Grid Layout -->
  <!-- <section class="gallery py-5 bg-light"> -->
    <section id="Categories" class="portfolio section-padding gallery py-5 bg-light">
        <div class="container">
                <div class="col-md-12">
                  <div class="section-header text-center pb-5">
                     <p style="color: rgb(6 187 204); font-size: xx-large;">Gallery</p>
                    <h2>Our Cuties</h2>
                    <p>Explore the beauty and majesty of cows, revered for their gentle nature and life-giving qualities. From their soft moos to their curious gazes, cows bring joy and serenity to our lives.</p>
                  </div>
                </div>
         </div>
        <div class="container">
         <div class="row">
            <div class="col-12 col-md-12 col-lg-6">
             <div class="card text-light text-center bg-white pb-2">
               <div class="card-body cat-body text-dark">
                  <div class="img-area cat1">
                   <img src="<?= base_url(); ?>public/web/img/a_cow_is_sitting_in_gaushala.jpeg" alt="" class="img-fluid">
                  </div>
               </div>
             </div>
             <div class="col-12 col-md-12 col-lg-12 d-lg-flex pt-5">
             <div class="col-12 col-md-12 col-lg-6 ">
                <div class="card text-light text-center bg-white pb-2 pe-2">
                  <div class="card-body cat-body text-dark">
                     <div class="img-area cat2">
                      <img src="<?= base_url(); ?>public/web/img/cow_with_there_baby_sitting_in_goushala (1).jpeg" alt="" class="img-fluid">
                     </div>
                  </div>
                </div>
               </div>
               <div class="col-12 col-md-12 col-lg-6">
                <div class="card text-light text-center bg-white pb-2  ps-2">
                  <div class="card-body cat-body text-dark">
                     <div class="img-area cat3">
                      <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala.jpeg" alt="" class="img-fluid">
                     </div>
                  </div>
                </div>
               </div>
              </div> 
            </div>
            <div class="col-12 col-md-12 col-lg-6">
             <div class="card text-light text-center bg-white pb-2">
               <div class="card-body cat-body text-dark">
                  <div class="img-area cat4">
                   <img src="<?= base_url(); ?>public/web/img/indian_cows_in_gaushala_in_landscape.jpeg" alt="" class="img-fluid">
                   <img src="<?= base_url(); ?>public/web/img/Untitled design (1).png" alt="" class="img-fluid mt-4">
                  </div>
               </div>
             </div>
            </div>
         </div>
        </div>
     </section>

     <section id="testimonials" class="py-5 ">
        <div class="container">
          <h2 class="text-center mb-4">What Our Supporters Say</h2>
          <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <div class="card testimonial-card mx-auto" style="max-width: 600px;">
                  <div class="card-body text-center">
                    <p class="card-text">"The Gau Shala is doing a wonderful job. I am truly touched by their dedication to cow protection and fostering traditional values."</p>
                    <h5 class="card-title mt-3">- Rahul Sharma</h5>
                    <p class="text-muted small">Long-time Supporter</p>
                  </div>
                </div>
              </div>
              <div class="carousel-item">
                <div class="card testimonial-card mx-auto" style="max-width: 600px;">
                  <div class="card-body text-center">
                    <p class="card-text">"I adopted a cow last year, and the experience has been deeply fulfilling. It's heartwarming to know I am making a difference."</p>
                    <h5 class="card-title mt-3">- Anjali Verma</h5>
                    <p class="text-muted small">Proud Adopter</p>
                  </div>
                </div>
              </div>
              <div class="carousel-item">
                <div class="card testimonial-card mx-auto" style="max-width: 600px;">
                  <div class="card-body text-center">
                    <p class="card-text">"The Gau Shala events bring people together. I always look forward to volunteering and connecting with the community."</p>
                    <h5 class="card-title mt-3">- Suresh Reddy</h5>
                    <p class="text-muted small">Volunteer</p>
                  </div>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </section>
      