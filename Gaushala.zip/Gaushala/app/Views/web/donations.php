<!-- Donation Methods Section -->
<section class="p-5 bg-white">

    <div class="container text-center justify-content-center">
        <div class="row text-center">
            <h2 class="text-center mb-4">Donation Methods</h2>
        </div>
    </div>

    <div class="container">
        <!-- One-Time Donations -->
        <div class="row mb-12">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">One-Time Donations</h5>
                        <p class="card-text">Make a single contribution to support the Gau Shala's activities. Your
                            one-time donation can help with daily operations, feed costs, and medical care for cows.
                            Additionally, your donation will also contribute to the maintenance of our facilities,
                            ensuring a safe and healthy environment for the cows. Every donation, big or small, brings
                            us closer to our goal of providing a sanctuary for these gentle creatures.</p>
                        <ul>
                            <li>₹500 – Provides one day's feed for a cow</li>
                            <li>₹1000 – Covers basic medical supplies for a week</li>
                            <li>₹2000 – Supports the maintenance of our facilities for a month</li>
                            <li>₹5000 – Contributes to the purchase of new equipment for cow</li>
                        </ul>
                        <a href="#donate" class="btn btn-primary">Donate Now</a>
                    </div>
                </div>
            </div>

            <!-- Recurring Donations -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Recurring Donations</h5>
                        <p class="card-text">Support us regularly through monthly, quarterly, or annual contributions.
                            Your recurring donations provide stable, ongoing support, ensuring uninterrupted care for
                            our cows.</p>
                        <a href="#recurring" class="btn btn-primary">Set Up Recurring Donation</a>
                    </div>
                </div>

                <!-- Adopt-a-Cow Sponsorship -->
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Adopt-a-Cow Sponsorship</h5>
                                <p class="card-text">Sponsor a cow and create a personal bond. You’ll receive updates on
                                    your cow’s progress, visit the cow at the Gau Shala, and have a lasting connection
                                    with your donation.</p>
                                <a href="#sponsor" class="btn btn-primary">Sponsor a Cow</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Payment Gateway Section -->
<section class="p-5 bg-light justify-content-center">
    <div class="container justify-content-center">
        <div class="row text-center">
            <h2 class="text-center mb-4">Payment Gateway Integration</h2>
        </div>
    </div>

    <div class="container">
        <!-- Card for Secure Payment Options -->
        <div class="card shadow-sm mb-4">
            <div class="card-body text-center">
                <h5 class="card-title">Secure Payment Options</h5>
                <p class="card-text">Choose from multiple secure payment methods, including credit/debit cards, UPI, and
                    PayPal. Your payment process is safe and reliable.</p>
                <ul class="list-unstyled">
                    <li>Credit/Debit Cards</li>
                    <li>UPI (Unified Payments Interface)</li>
                    <li>PayPal</li>
                </ul>
                <p><small>Payments are processed securely with SSL encryption and trusted payment gateways.</small></p>
            </div>
        </div>

        <!-- Card for International Payment Support -->
        <div class="card shadow-sm">
            <div class="card-body text-center">
                <h5 class="card-title">International Payment Support</h5>
                <p class="card-text">We support international payments, making it easy for global supporters to donate.
                    You can donate in different currencies with options like credit cards, UPI, and PayPal.</p>
            </div>
        </div>
    </div>
</section>


<!-- Printable Certificates Section -->
<section class="p-5 bg-white">
    <div class="row container text-center justify-content-center">
        <h2 class="text-center mb-4">Printable Donation Certificates</h2>
        <p class="text-center mb-5">Receive a personalized donation certificate after your contribution.<br> The
            certificate includes your donation details and a personalized message of gratitude.</p>
    </div>


    <div class="container">
        <!-- Row for Cards -->
        <div class="row">
            <!-- Card for Automatic Donation Certificates -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <h5 class="card-title">Automatic Donation Certificates</h5>
                        <p class="card-text">Your personalized donation certificate will be available for download after
                            the transaction or sent via email. The certificate includes your details and donation
                            amount, along with the Gau Shala’s contact info and logo.</p>
                    </div>
                </div>
            </div>

            <!-- Card for Tax Deduction Information -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <h5 class="card-title">Tax Deduction Information</h5>
                        <p class="card-text">If your donation is eligible for tax deductions, we provide necessary
                            details in the certificate to help you with tax filing.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Donation FAQs Section -->
<section class="p-5 bg-white">
    <div class="container text-center justify-content-center">
        <div class="row justify-content-center w-100">
            <h2 class="text-center mb-4">Donation FAQs</h2>
        </div>
    </div>

    <div class="container justify-content-center">
        <!-- FAQs List -->
        <div class="row">
            <!-- Left Column FAQs -->
            <div class="col-md-12">
                <!-- FAQ Item 1 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq1" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq1">
                            What are the different ways I can donate?
                        </a>
                    </h5>
                    <div id="faq1" class="collapse">
                        <p>We offer one-time donations, recurring donations, and an Adopt-a-Cow program. Choose the
                            method that best suits your preferences.</p>
                    </div>
                </div>

                <!-- FAQ Item 2 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq2" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq2">
                            How secure is the online donation process?
                        </a>
                    </h5>
                    <div id="faq2" class="collapse">
                        <p>Our payment gateway uses SSL encryption to ensure your transactions are safe and secure.</p>
                    </div>
                </div>

                <!-- FAQ Item 3 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq3" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq3">
                            Is my donation tax-deductible?
                        </a>
                    </h5>
                    <div id="faq3" class="collapse">
                        <p>Donations are eligible for tax deductions. Please check the details provided on your donation
                            certificate.</p>
                    </div>
                </div>
            </div>

            <!-- Right Column FAQs -->
            <div class="col-md-12">
                <!-- FAQ Item 4 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq4" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq4">
                            Can I receive updates on how my donation is used?
                        </a>
                    </h5>
                    <div id="faq4" class="collapse">
                        <p>Yes, we provide updates to sponsors and donors, including regular reports and newsletters
                            about the impact of your donation.</p>
                    </div>
                </div>

                <!-- FAQ Item 5 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq5" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq5">
                            How do I sponsor a cow?
                        </a>
                    </h5>
                    <div id="faq5" class="collapse">
                        <p>Visit our Adopt-a-Cow page to choose a cow to sponsor. You will receive updates and have the
                            opportunity to visit your sponsored cow.</p>
                    </div>
                </div>

                <!-- FAQ Item 6 -->
                <div class="faq-item border p-3 mb-3 text-center rounded">
                    <h5>
                        <a href="#faq6" class="text-dark" data-toggle="collapse" role="button" aria-expanded="false"
                            aria-controls="faq6">
                            What is the refund policy on donations?
                        </a>
                    </h5>
                    <div id="faq6" class="collapse">
                        <p>We handle donations as final, and refunds are only provided in case of accidental payments.
                            Please contact us for any issues.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>