<!-- Introduction Section -->
<section class="p-5">
  <div class="container">
    <div class="row">

        <h2 class="text-center mb-4">About Us</h2>
        <p class="lead text-center">Our mission is to honor Gau Mata by providing a sanctuary dedicated to her care, fostering compassion, and preserving cultural traditions.</p>
    </div>
  </div>
  
  <div class="container">
    <div class="row">
        <div class="row mt-4">
            <div class="col-md-6">
              <h4>Our Story</h4>
              <p>The Gau Shala was founded in 2005, inspired by traditional values and the importance of cow protection in Hindu culture. Since then, it has provided shelter for over 500 cows, promoting welfare and protection for these sacred animals.</p>
            </div>
            <div class="col-md-6">
              <h4>Our Mission</h4>
              <p>Our mission is to create a safe haven for cows, uphold cultural heritage, and foster community engagement. We strive to protect, honor, and nurture every cow within our sanctuary.</p>
            </div>
          </div>
    </div>
  </div>
    
    <hr class="my-4">
    <div class="timeline">
      <h4 class="text-center mb-4">Our Journey</h4>
      <!-- Timeline Example, Modify as Needed -->
      <ul class="list-unstyled text-center">
        <li>2005 - Foundation of the Gau Shala</li>
        <li>2010 - Reached 200 cows in care</li>
        <li>2015 - Built the on-site Shiv Temple</li>
        <li>2020 - Established Green Gym for visitors</li>
      </ul>
    </div>
  </div>
</section>

<!-- Facilities Overview Section -->
<section class="p-5 bg-light">
    <div class="container text-center justify-content-center">
        <div class="row text-center">
            <h2 class="text-center mb-4 text-center">Our Facilities</h2>
        </div>
    </div>
  <div class="container">
    <div class="row text-center">
      <div class="col-md-3 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Green Gym">
          <div class="card-body">
            <h5 class="card-title">Green Gym</h5>
            <p class="card-text">Engage in outdoor exercise surrounded by nature and cows, promoting wellness and a connection with nature.</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Gazebo">
          <div class="card-body">
            <h5 class="card-title">Gazebo</h5>
            <p class="card-text">A peaceful relaxation spot for visitors to unwind, meditate, and enjoy the serene environment.</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Shiv Temple">
          <div class="card-body">
            <h5 class="card-title">Shiv Temple</h5>
            <p class="card-text">A sacred space for spiritual practices, allowing visitors to seek blessings and connect with the divine.</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/gaushala-logo.png" class="card-img-top" alt="Banquet Hall">
          <div class="card-body">
            <h5 class="card-title">Banquet Hall</h5>
            <p class="card-text">A venue for community gatherings and events, supporting the Gau Shala's maintenance and mission.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Team Information Section -->
<section class="p-5 bg-white">
    <div class="container text-center justify-content-center">
        <div class="row text-center">
            <h2 class="text-center mb-4 text-center">Our Team</h2>
        </div>
    </div>
  <div class="container">
    <!-- <h2 class="text-center mb-4">Our Team</h2> -->
    <div class="row text-center">
      <!-- Team Member 1 -->
      <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Anjali Patel">
          <div class="card-body">
            <h5 class="card-title">Anjali Patel</h5>
            <p class="card-text">Head of Animal Welfare</p>
            <p>With over 10 years in veterinary care, Anjali ensures the health and happiness of every cow in our Gau Shala.</p>
          </div>
        </div>
      </div>
      <!-- Team Member 2 -->
      <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/img2.jpg" class="card-img-top" alt="Ram Singh">
          <div class="card-body">
            <h5 class="card-title">Ram Singh</h5>
            <p class="card-text">Facility Manager</p>
            <p>Ram oversees daily operations and ensures the Gau Shala remains a safe, organized, and serene environment.</p>
          </div>
        </div>
      </div>
      <!-- Team Member 3 -->
      <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm">
          <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="card-img-top" alt="Priya Desai">
          <div class="card-body">
            <h5 class="card-title">Priya Desai</h5>
            <p class="card-text">Volunteer Coordinator</p>
            <p>Priya manages our volunteers, inspiring and organizing community members to engage in Gau Seva.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container justify-content-center">
    <div class="row justify-content-center text-center mt-4">
        <a href="#volunteer" class="btn btn-primary">Join Us</a>
      </div>
</div>
</section>