
<section class="p-5 bg-white">
    <div class="container justify-content-center">
        <div class="row">
            <h2 class="text-center mb-5">Upcoming Events</h2>
        </div>

    </div>


  <div class="container">
    <div class="row w-100">
      <!-- Calendar Section -->
      <div class="col-md-6 mb-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title text-center">Event Calendar</h5>
            <div class="calendar text-center">
              <!-- Calendar view placeholder (can be replaced with JavaScript calendar library) -->
              <p>[Interactive Calendar Here]</p>
            </div>
            <p class="text-center mt-3">Click on events to view more details.</p>
          </div>
        </div>
      </div>
      <!-- Filter Section -->
      <div class="col-md-6 mb-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title text-center">Filter Events</h5>
            <form>
              <div class="form-group">
                <label for="eventType">Event Type</label>
                <select id="eventType" class="form-control">
                  <option>All Events</option>
                  <option>Festivals</option>
                  <option>Workshops</option>
                  <option>Community Gatherings</option>
                </select>
              </div>
              <div class="form-group">
                <label for="timeFrame">Timeframe</label>
                <select id="timeFrame" class="form-control">
                  <option>This Week</option>
                  <option>This Month</option>
                  <option>Upcoming Events</option>
                </select>
              </div>
              <button type="button" class="btn btn-primary btn-block mt-3">Apply Filters</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="p-5 bg-light">
    <div class="container justify-content-center">
        <div class="row">
            <h2 class="text-center mb-5">Event Details</h2>
        </div>

    </div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 mb-4 ">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title text-center">[Event Title]</h5>
            <p><strong>Date:</strong> [Event Date]</p>
            <p><strong>Time:</strong> [Event Time]</p>
            <p><strong>Location:</strong> [Location Name] <a href="#">View Map</a></p>
            <p><strong>Description:</strong> Detailed information about the event, including activities, highlights, and purpose. For example, cultural practices, notable speakers, etc.</p>
            <div class="image-gallery">
              <h6>Gallery</h6>
              <!-- Placeholder images (add actual images) -->
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
              <img src="https://via.placeholder.com/150" class="img-thumbnail mr-2" alt="Event Image">
            </div>
          </div>
        </div>
      </div>

      <!-- Event Registration Form -->
      <div class="container my-5">
        <div class="col-md-12 mb-4">
          <div class="card shadow-sm">
            <div class="row no-gutters">
              
              <!-- Registration Form Section -->
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title text-center">Register for Event</h5>
                  <form>
                    <div class="form-group">
                      <label for="name">Full Name</label>
                      <input type="text" class="form-control" id="name" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" id="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                      <label for="participants">Number of Participants</label>
                      <input type="number" class="form-control" id="participants" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block mt-3">Submit Registration</button>
                  </form>
                </div>
              </div>
      
              <!-- Image/GIF Section -->
              <div class="col-md-4">
                <img src="<?= base_url(); ?>public/web/img/img1.jpg" class="img-fluid h-100" alt="Event Image">
                <!-- Alternatively, add a GIF with this format:
                <img src="./img/your-image.gif" class="img-fluid h-100" alt="Event GIF"> -->
              </div>
              
            </div>
          </div>
        </div>
      </div>
      

    </div>
  </div>
</section>

<section class="p-5 bg-white">
    <div class="container justify-content-center">
        <div class="row">
            <h2 class="text-center mb-5">Volunteer Opportunities</h2>
        </div>
    </div>


  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="card-title text-center">Volunteer Roles</h5>
            <p>Join us in making the event a success! We need volunteers for various roles, including event setup, registration assistance, and animal care. Volunteering offers hands-on experience and the opportunity to engage in meaningful work. You can contribute to the event's success by helping with event promotion, coordinating logistics, or providing support to our team. Your involvement will not only enhance the event experience but also contribute to the well-being of the animals in our care. We welcome your participation and look forward to working together to make this event a memorable one.</p>

          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title text-center">Volunteer Signup</h5>
            <form>
              <div class="form-group">
                <label for="volunteerName">Full Name</label>
                <input type="text" class="form-control" id="volunteerName" placeholder="Your Name" required>
              </div>
              <div class="form-group">
                <label for="volunteerEmail">Email</label>
                <input type="email" class="form-control" id="volunteerEmail" placeholder="Your Email" required>
              </div>
              <div class="form-group">
                <label for="availability">Availability</label>
                <input type="text" class="form-control" id="availability" placeholder="Your Availability" required>
              </div>
              <button type="submit" class="btn btn-primary btn-block mt-3">Sign Up to Volunteer</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
