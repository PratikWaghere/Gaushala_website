<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        $view = view('web/header')
            . view('web/home')
            . view('web/footer');
        return $view;
    }

    public function about(): string
    {
        $view = view('web/header')
            . view('web/about')
            . view('web/footer');
        return $view;
    }
    public function services(): string
    {
        $view = view('web/header')
            . view('web/services')
            . view('web/footer');
        return $view;
    }
    public function donations(): string
    {
        $view = view('web/header')
            . view('web/donations')
            . view('web/footer');
        return $view;
    }
    public function events(): string
    {
        $view = view('web/header')
            . view('web/events')
            . view('web/footer');
        return $view;
    }
    public function gallery(): string
    {
        $view = view('web/header')
            . view('web/gallery')
            . view('web/footer');
        return $view;
    }
    public function contact(): string
    {
        $view = view('web/header')
            . view('web/contact')
            . view('web/footer');
        return $view;
    }

    
}
