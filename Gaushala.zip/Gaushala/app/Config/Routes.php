<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// web routes
$routes->get('/', 'Home::index');
$routes->get('about', 'Home::about');
$routes->get('services', 'Home::services');
$routes->get('donations', 'Home::donations');
$routes->get('events', 'Home::events');
$routes->get('gallery', 'Home::gallery');
$routes->get('contact', 'Home::contact');
